const ProductosMaxima = [
    {
     id: 01,
     imagen: '../images/Tortas/cremaFrutillaPortada.jpeg',
     nombre:'Torta Crema-Frutilla',
     descripcion:'Torta de vainilla, crema y frutillas con decoración de crema y chocolate.' ,
     precio: 1800,
     categoria:'Tortas'
    },
    {
     id: 02,
     imagen: '../images/Tortas/ChocoletterPortada.jpeg',
     nombre:'Chocoletter',
     descripcion:'Chocotorta con forma de una letra a elección y toppings de oreo y bombon.' ,
     precio: 2100,
     categoria:'Tortas'
    },
    {
     id: 03,
     imagen: '../images/Tortas/tortaRosaPortada.jpeg',
     nombre:'Torta Butter-Frutilla',
     descripcion:'Torta de vainilla con crema  frutillas y decoración de buttercream y toppings.' ,
     precio: 2600,
     categoria:'Tortas'
    },
    {
     id: 04,
     imagen: '../images/Tortas/tortaRockletsPortada.jpeg',
     nombre:'Torta Rocklets',
     descripcion:'Torta ideal para cumpleaños infantiles, de dulce de leche y confites.' ,
     precio: 1700,
     categoria:'Tortas'
    },
    {
     id: 05,
     imagen: '../images/Tortas/Torta alta Chocolate.jpeg',
     nombre: 'Torta Butter-Chocolate',
     descripcion:'Torta de biscochuelo, relleno y toppings de chocolate de tres pisos.' ,
     precio: 2700,
     categoria:'Tortas'
    },
    {
     id: 06,
     imagen: '../images/Postres/Chocotorta.jpeg',
     nombre: 'Chocotorta',
     descripcion:'Pequeña chocotorta en envase plastico para uno con cacao espolvoreado.' ,
     precio: 800,
     categoria:'Postres'
    },
    {
     id: 07,
     imagen: '../images/Postres/Mouse-menta.jpeg',
     nombre: 'Mouse de menta',
     descripcion:'Pequeño mouse de chocolate amargo con topping de medallón de menta picado.' ,
     precio: 600,
     categoria:'Postres'
    },
    {
     id: 08,
     imagen: '../images/Postres/Nugaton.jpeg',
     nombre: 'Nugatón',
     descripcion:'Postre de avena con chocolate en capas de galletita seca, para 2 personas.' ,
     precio: 800,
     categoria: 'Postres'
    },
    {
     id: 09,
     imagen: '../images/Postres/Tiramisu.jpeg',
     nombre: 'Tiramisú',
     descripcion:'Postre de mascarpone en capas de vainillas mojadas en licor de café.' ,
     precio: 1100,
     categoria:'Postres'
    },
    {
     id: 010,
     imagen: '../images/Postres/Trufas.jpeg',
     nombre: 'Trufas',
     descripcion:'Postre de torta y dulce de leche envuelta en grana.' ,
     precio: 450,
     categoria:'Postres'
    },
    {
     id: 011,
     imagen: '../images/Boxes-combos/NetflixBox.jpeg',
     nombre: 'Netflix Box',
     descripcion:'Kit para ver peliculas, incluye postre y regalo especial.' ,
     precio: 1200,
     categoria:'Especiales'
    },
    {
     id: 012,
     imagen: '../images/Boxes-combos/BoxTeamo.jpeg',
     nombre: 'Box San Valentín',
     descripcion:'Chocolate hueco lleno de golosinas para regalar.' ,
     precio: 1600,
     categoria:'Especiales'
    },
    {
     id: 013,
     imagen: '../images/Boxes-combos/LemonAb.jpeg',
     nombre: 'Mini lemon-pie',
     descripcion:'Pequeños lemon-pie para compartir en familia.' ,
     precio: 1600,
     categoria:'Especiales'
    },
    {
     id: 014,
     imagen: '../images/Boxes-combos/MixTortitas.jpeg',
     nombre: 'Mix de Tortitas',
     descripcion:'Pack de mini degustación de las tortas que ofrecemos.' ,
     precio: 1200,
     categoria:'Especiales'
    },
    {
     id: 015,
     imagen: '../images/Huevos/Huevo-Oreo.jpeg',
     nombre: 'Huevo Oreo',
     descripcion:'Medio huevo relleno de crema oreo y toppings.' ,
     precio: 2000,
     categoria:'Especiales'
    },
    {
     id: 016,
     imagen: '../images/Huevos/Huevo-Roclets.jpeg',
     nombre: 'Huevo Rocklets',
     descripcion:'Medio huevo relleno de nutela, chocolate y confites.' ,
     precio: 2000,
     categoria:'Especiales'
    }
];

let carrito = [];
const divisa = '$';
const DOMitems = document.querySelector('main');
const DOMcarrito = document.querySelector('#carrito');
const DOMtotal = document.querySelector('#total');
const DOMcant = document.querySelector('#cant');
const DOMbotonVaciar = document.querySelector('#boton-vaciar');
const DOMlistado = document.querySelector('#listado');
const DOMlink = document.querySelector('#link');
const clienteLocalStorage = window.localStorage;

function crearTarjetaProductos() {
    ProductosMaxima.forEach((info) => {
        // Estructura
        const nuevoNodo = document.createElement('div');
        nuevoNodo.classList.add('card', 'col-sm-4');
        // Cuerpo
        const nodoCuerpo = document.createElement('div');
        nodoCuerpo.classList.add('card-body');
        // Titulo
        const nodoTitulo = document.createElement('h5');
        nodoTitulo.classList.add('card-title');
        nodoTitulo.textContent = info.nombre;
        // Imagen
        const nodoImagen = document.createElement('img');
        nodoImagen.classList.add('img-fluid');
        nodoImagen.setAttribute('src', info.imagen);
        //Descripcion
        const nodoDetalle = document.createElement('p');
        nodoDetalle.textContent = info.descripcion;
        // Precio
        const nodoPrecio = document.createElement('p');
        nodoPrecio.classList.add('card-text');
        nodoPrecio.textContent = `${info.precio}${divisa}`;
        // Boton 
        const nodoBoton = document.createElement('button');
        nodoBoton.classList.add('btn', 'btn-primary');
        nodoBoton.textContent = 'Añadir';
        nodoBoton.setAttribute('marcador', info.id);
        nodoBoton.addEventListener('click', agregarCarrito);
        // Insertar
        //console.log(DOMitems);
        if (DOMitems.id == info.categoria) {
        nodoCuerpo.appendChild(nodoImagen);
        nodoCuerpo.appendChild(nodoTitulo);
        nodoCuerpo.appendChild(nodoDetalle);
        nodoCuerpo.appendChild(nodoPrecio);
        nodoCuerpo.appendChild(nodoBoton);
        nuevoNodo.appendChild(nodoCuerpo);
        DOMitems.appendChild(nuevoNodo);
        }
    }); 
}

function guardarCarritoEnLocalStorage () {
    clienteLocalStorage.setItem('carrito', JSON.stringify(carrito));
}

function mialerta() { 
    alert("¡Producto añadido al carrito!");
}

function agregarCarrito(evento){
    carrito.push(evento.target.getAttribute('marcador'));
    guardarCarritoEnLocalStorage();
    //crea la alerta
    mialerta();
    //actualiza los montos en la parte superior del navegador
    DOMcant.textContent=carrito.length;
    DOMtotal.textContent=calcularTotal();
}

function cargarCarritoDeLocalStorage () {
    if (clienteLocalStorage.getItem('carrito') !== null) {
        carrito = JSON.parse(clienteLocalStorage.getItem('carrito'));
    }
}

function listarCarrito(e) {
    if(DOMcarrito){
        DOMcarrito.textContent =``;
        const carritoProductos = [...new Set(carrito)];
        carritoProductos.forEach((item) => {
        const miItem = ProductosMaxima.filter((itemProductosMaxima) => {
            return itemProductosMaxima.id === parseInt(item);
        });
        const numeroUnidadesItem = carrito.reduce((total, itemId) => {
            return itemId === item ? total += 1 : total;
        }, 0);
        // Crear el nodo del item del carrito
        const listaNodo = document.createElement('li');
        listaNodo.classList.add('list-group-item', 'text-right', 'mx-2');
        listaNodo.textContent = `${numeroUnidadesItem} x ${miItem[0].nombre} - ${miItem[0].precio}${divisa}`;
        // Boton de borrar
        const BotonBorrar = document.createElement('button');
        BotonBorrar.classList.add('btn', 'btn-danger', 'mx-5');
        BotonBorrar.textContent = 'X';
        BotonBorrar.style.marginLeft = '1rem';
        BotonBorrar.dataset.item = item;
        BotonBorrar.addEventListener('click', borrarItemCarrito);

        listaNodo.appendChild(BotonBorrar);
        DOMcarrito.appendChild(listaNodo);
    });
    }
    if(DOMtotal){
        // Calcula precio total
        DOMtotal.textContent = calcularTotal();}
    if(DOMcant){
        //Dice la cantidad de articulos
        DOMcant.textContent = carrito.length;
    }
    //Habilita Botón Vaciar carrito
    if(carrito.length!=0 && DOMbotonVaciar){
        DOMbotonVaciar.addEventListener('click', vaciarCarrito);
        DOMbotonVaciar.textContent =`Vaciar`;} 
    if(carrito.length==0 && DOMbotonVaciar) {
        DOMbotonVaciar.textContent =`¿Qué hace acá? ¡Vaya a comprar una torta!`;
    }
}

function borrarItemCarrito(evento) {
    const id = evento.target.dataset.item;
    carrito = carrito.filter((carritoId) => {
        return carritoId !== id;
    });

    listarCarrito();
    guardarCarritoEnLocalStorage();
}

function calcularTotal() {   
    return carrito.reduce((total, item) => {
        const miItem = ProductosMaxima.filter((itemProductosMaxima) => {
            return itemProductosMaxima.id === parseInt(item);
        });
        return total + miItem[0].precio;
    }, 0).toFixed(2);
}

function vaciarCarrito() {
    carrito = [];
    localStorage.clear();
    listarCarrito();
}

cargarCarritoDeLocalStorage();

if(DOMcarrito){
    listarCarrito();
}

if (DOMitems) {
    crearTarjetaProductos();
    DOMcant.textContent=carrito.length;
    DOMtotal.textContent=calcularTotal();
}

